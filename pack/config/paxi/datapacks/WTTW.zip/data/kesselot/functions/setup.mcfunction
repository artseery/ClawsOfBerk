scoreboard objectives add ke.first dummy
execute unless score %USED ke.first matches 2.. run schedule function kesselot:wttw 100t
scoreboard players set %USED ke.first 2